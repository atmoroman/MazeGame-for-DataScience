using UnityEngine;

public class bottleScore1 : MonoBehaviour
{
  public int score;


    void Update()
    {
        Debug.Log(score);
    }
}
