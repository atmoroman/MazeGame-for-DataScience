using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;
using UnityEngine.UI;

public class finishGame : MonoBehaviour
{
    [SerializeField] private GameObject canvas;
    public AudioMixer audioMixer;
    public Slider musicSlider;
    public Slider sfxSlider;

    private bool isPaused = false; 

    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPaused)
            {
                Resume();
            }
            else
            {
                OpenMenu();
            }
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Player"))
        {
            Time.timeScale = 1f; 
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            SceneManager.LoadScene("FinishCongrats");
        }
    }

    public void OpenMenu()
    {
        canvas.SetActive(true);
        Time.timeScale = 0f; // PAUSE
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        isPaused = true;
    }

    public void Resume()
    {
        canvas.SetActive(false);
        Time.timeScale = 1f; 
        Cursor.lockState = CursorLockMode.Locked; 
        Cursor.visible = false;
        isPaused = false;
    }

    public void QuitToFinishScene() 
    {
        SceneManager.LoadScene("GameFinish");
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    public void QuitApplication()
    {
        Application.Quit();
    }


    public void UpdateMusicVolume(float volume)
    {
        audioMixer.SetFloat("MusicVolume", volume);
    }
    public void UpdateSoundVolume(float volume)
    {
        audioMixer.SetFloat("SFXVolume", volume);
    }

    public void SaveVolume()
    {
        audioMixer.GetFloat("MusicVolume", out float musicVolume);
        PlayerPrefs.SetFloat("MusicVolume", musicVolume);
 
        audioMixer.GetFloat("SFXVolume", out float sfxVolume);
        PlayerPrefs.SetFloat("SFXVolume", sfxVolume);
    }
 
    public void LoadVolume()
    {
        musicSlider.value = PlayerPrefs.GetFloat("MusicVolume");
        sfxSlider.value = PlayerPrefs.GetFloat("SFXVolume");
    }

    public void PlayHover()
    {
        SoundManager.Instance.PlaySound2D("Hover");
    }
    public void PlayClick()
    {
        SoundManager.Instance.PlaySound2D("Click");
    }
}