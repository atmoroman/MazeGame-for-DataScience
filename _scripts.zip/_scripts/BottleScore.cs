using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class BottleScore : MonoBehaviour
{
    [SerializeField] GameObject gate;
    private bottleScore1 count;

    void Start()
    {
        count = GameObject.FindGameObjectWithTag("Player").GetComponent<bottleScore1>();
    }
    void Update()
    {
        if(gate != null && count.score >= 5)
        {
            SoundManager.Instance.PlaySound2D("Gates");
            Destroy(gate);
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Player"))
        {
            SoundManager.Instance.PlaySound2D("Bottles");
            count.score +=1;
            Destroy(gameObject,0.1f);
        }
    }

}
