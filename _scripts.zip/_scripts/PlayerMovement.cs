using UnityEngine;
using UnityEngine.Tilemaps;

public class GridMovementTilemapSafe : MonoBehaviour
{
    public float gridSize = 1f;      
    public float moveSpeed = 5f;       
    public Tilemap mazeTilemap;        

    public Animator animator;           
    public SpriteRenderer spriteRenderer; 

    private bool isMoving = false;
    private Vector3 targetPos;
    private Vector3 lastDirection = Vector3.right; 

    void Start()
    {
        targetPos = transform.position;
        if (animator == null) animator = GetComponent<Animator>();
        if (spriteRenderer == null) spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        if (!isMoving)
        {
            Vector3 direction = Vector3.zero;

            if (Input.GetKey(KeyCode.W)) direction = Vector3.up;
            if (Input.GetKey(KeyCode.S)) direction = Vector3.down;
            if (Input.GetKey(KeyCode.A)) direction = Vector3.left;
            if (Input.GetKey(KeyCode.D)) direction = Vector3.right;

            if (direction != Vector3.zero)
            {
                lastDirection = direction;

                Vector3 nextPos = targetPos + direction * gridSize;

                if (!IsWall(nextPos))
                {
                    targetPos = nextPos;
                    StartCoroutine(Move());
                }
            }
        }

        // --- Animation handling ---
        if (animator != null)
        {
            animator.SetBool("isMoving", isMoving);
        }

        if (spriteRenderer != null)
        {
            if (lastDirection.x < 0)
                spriteRenderer.flipX = true;
            else if (lastDirection.x > 0)
                spriteRenderer.flipX = false;
        }
    }

    bool IsWall(Vector3 worldPos)
    {
        Vector3Int cellPos = mazeTilemap.WorldToCell(worldPos);
        return mazeTilemap.HasTile(cellPos); 
    }

    System.Collections.IEnumerator Move()
    {
        isMoving = true;

        while ((transform.position - targetPos).sqrMagnitude > 0.0001f)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPos, moveSpeed * Time.deltaTime);
            yield return null;
        }

        transform.position = targetPos;
        isMoving = false;
    }
}
